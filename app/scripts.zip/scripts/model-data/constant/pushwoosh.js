'use strict';
/* **********************************************************************
 * @author: ${USER}
 * @date  : ${DATE}
 * @name Outfitpic.constant:TimeZone
 *
 * **********************************************************************
 * @copyright All rights reserved by Outfitpic Inc 2015
 * **********************************************************************
 * @ngdoc constant
 * @description Timezone config for timestamp on comment posts
 *
 */

angular.module('Outfitpic.Constant.PushWoosh', [])

  .constant('PUSHWOOSH', {
    APPID: '69CC2-C4967',
    APIKEY: 'QVipmioC7Ik6F1YPKJrOBWx4teGBMs2m0l4m3AzakRddV6eD0pSYwMJQaEy5InpKPWh2sWsVgi28ZrHZUin6'
  });
