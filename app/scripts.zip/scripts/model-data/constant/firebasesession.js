'use strict';
/* **********************************************************************
 * @author: ${USER}
 * @date  : ${DATE}
 * @name Outfitpic.constant:FIREBASE_URL
 *
 * **********************************************************************
 * @copyright All rights reserved by Outfitpic Inc 2015
 * **********************************************************************
 * @ngdoc constant
 * @description FIREBASE SESSION constant data
 *
 */
 
angular.module('Outfitpic.Constant.FirebaseSession', [])
	.constant('FIREBASE_SESSION', 'firebase:session::outfitpictest');

